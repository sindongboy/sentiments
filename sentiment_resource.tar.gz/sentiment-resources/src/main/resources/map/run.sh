#!/bin/bash




while read line
do
	omp=`echo "${line}" | cut -f 3`
	size=`echo "${line}" | cut -f 4`
	IFS=\n
	for match in `cat ./category-mapping.tsv | cut -f 2- | grep "^${omp}	"`
	do
		echo "${size}	${match}"
	done

done < ./knowledge

